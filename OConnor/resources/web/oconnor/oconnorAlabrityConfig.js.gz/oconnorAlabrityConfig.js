//this file contains site-specific settings to make alabrity modules portable to other LabKey systems, like the WNPRC EHR

var dbSchemaName = 'oconnor';
var moduleName = 'oconnor';